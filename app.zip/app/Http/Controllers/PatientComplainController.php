<?php

namespace App\Http\Controllers;

use App\Models\PatientComplain;
use App\Http\Requests\StorePatientComplainRequest;
use App\Http\Requests\UpdatePatientComplainRequest;

class PatientComplainController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePatientComplainRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PatientComplain $patientComplain)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PatientComplain $patientComplain)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePatientComplainRequest $request, PatientComplain $patientComplain)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PatientComplain $patientComplain)
    {
        //
    }
}
