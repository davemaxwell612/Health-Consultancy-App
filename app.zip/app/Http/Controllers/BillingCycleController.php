<?php

namespace App\Http\Controllers;

use App\Models\BillingCycle;
use App\Http\Requests\StoreBillingCycleRequest;
use App\Http\Requests\UpdateBillingCycleRequest;

class BillingCycleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreBillingCycleRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(BillingCycle $billingCycle)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(BillingCycle $billingCycle)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateBillingCycleRequest $request, BillingCycle $billingCycle)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(BillingCycle $billingCycle)
    {
        //
    }
}
